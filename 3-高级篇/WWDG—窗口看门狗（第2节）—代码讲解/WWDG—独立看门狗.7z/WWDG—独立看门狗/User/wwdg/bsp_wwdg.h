#ifndef __BSP_WWDG_H
#define	__BSP_WWDG_H

#include "stm32f4xx.h"
#include "./led/bsp_led.h"

void WWDG_Feed(void);
void WWDG_Config(uint8_t tr, uint8_t wr, uint32_t prv);

#endif  /*__BSP_WWDG_H*/


