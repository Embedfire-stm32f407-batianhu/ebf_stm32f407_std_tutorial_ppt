#include "stm32f10x.h"
#include "./led/bsp_led.h"
#include "./uart/bsp_uart_dma.h"

extern uint8_t SendBuff[SENDBUFF_SIZE];


void delay(uint32_t count)
{
	for(; count!=0; count--);
}

int main(void)
{
	uint32_t i;
	
	LED_GPIO_Config();
	
	DEBUG_UART_Config();	
	USARTx_DMA_Config();
	
	  /*��佫Ҫ���͵�����*/
  for(i=0;i<SENDBUFF_SIZE;i++)
  {
    SendBuff[i]	 = 'P';    
  }

	USART_DMACmd(DEBUG_USARTx, USART_DMAReq_Tx, ENABLE);
	while(1)
  {
		    LED1_TOGGLE
    delay(0xFFFFF);
	}

}

