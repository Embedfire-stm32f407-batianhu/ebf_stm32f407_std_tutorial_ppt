#include "stm32f10x.h"
#include "./advancetime/bsp_advancetime.h"



int main(void)
{
	ADVANCE_TIM_Init();
	while(1);
}

