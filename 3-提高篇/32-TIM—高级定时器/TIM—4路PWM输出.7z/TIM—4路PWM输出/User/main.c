#include "stm32f10x.h"
#include "./led/bsp_led.h"
#include "./uart/bsp_uart.h"
#include "./generaltim/bsp_generaltim.h"

void delay(uint32_t count)
{
	for(; count!=0; count--);
}

int main(void)
{	
	DEBUG_UART_Config();
	
	GENERAL_TIM_Init();
	
	while(1)
  {
	}
}

