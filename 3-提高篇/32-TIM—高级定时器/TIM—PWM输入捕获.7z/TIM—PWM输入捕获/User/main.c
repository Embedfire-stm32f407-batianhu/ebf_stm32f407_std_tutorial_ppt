#include "stm32f10x.h"
#include "./uart/bsp_uart.h"
#include "./generaltim/bsp_generaltim.h"
#include "./advancetim/bsp_advancetim.h"


int main(void)
{	
	DEBUG_UART_Config();
	
	GENERAL_TIM_Init();
	
	ADVANCE_TIM_Init();
	
	while(1)
  {
	}
}

