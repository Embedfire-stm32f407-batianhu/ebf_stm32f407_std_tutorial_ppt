#ifndef _BSP_LED_H
#define _BSP_LED_H

#include "stm32f4xx.h"

void LED_GPIO_Config(void);

#endif  /* _BSP_LED_H */

