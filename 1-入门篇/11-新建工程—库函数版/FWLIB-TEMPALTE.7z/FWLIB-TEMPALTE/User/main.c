#include "stm32f4xx.h"

int main(void)
{
	/* 在这里添加你自己的程序 */
	while(1);
}

