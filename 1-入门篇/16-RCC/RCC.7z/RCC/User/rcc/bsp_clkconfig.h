#ifndef __BSP_CLKCONFIG_H  
#define __BSP_CLKCONFIG_H

#include "stm32f10x.h"

void HSE_SetSysClk(uint32_t RCC_PLLMul);
void MCO_GPIO_Config(void);
void HSI_SetSysClk(uint32_t RCC_PLLMul);

#endif  /* __BSP_CLKCONFIG_H */


